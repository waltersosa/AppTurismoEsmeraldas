const config = {
  port: 3002,
  mongoUri: 'mongodb://localhost:27017/placesDB',
  jwtSecret: 'secretAuth'
};

export default config; 