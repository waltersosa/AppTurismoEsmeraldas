const config = {
  port: 3001,
  jwtSecret: 'secretAuth',
  dbUri: 'mongodb://localhost:27017/authDB',
};

export default config; 